﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BakeryInventorySystem
{
    public partial class frmLogin : Form
    {
        Form1 frm;
        public frmLogin(Form1 frm)
        {
            InitializeComponent();
            this.frm = frm;
        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\GIZMOSBUIY\source\repos\bakeryinventorysystem\bakeryinventorysystem\BakeryInventorySystem\Shop.mdf;Integrated Security=True");
        

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (UnameTb.Text =="" || PassTb.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    String query = ("selected *  from LoginTbl Where uname=" + UnameTb.Text + ",and Upass=" + PassTb.Text + "");
                    Con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(query,Con);
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.BeginExecuteNonQuery();
                    MessageBox.Show("user suessfully login");

                    Con.Close();
                    
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }

        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
